import java.util.Scanner;
import java.util.ArrayList;

class User {
    private String userId;
    private String pin;

    public User(String userId, String pin) {
        this.userId = userId;
        this.pin = pin;
    }

    public boolean authenticate(String userId, String pin) {
        return this.userId.equals(userId) && this.pin.equals(pin);
    }
}

class Account {
    private double balance;
    private ArrayList<Transaction> transactionHistory;

    public Account() {
        this.balance = 0.0;
        this.transactionHistory = new ArrayList<>();
    }

    public double getBalance() {
        return balance;
    }

    public void deposit(double amount) {
        this.balance += amount;
        transactionHistory.add(new Transaction("Deposit", amount));
    }

    public boolean withdraw(double amount) {
        if (amount <= balance) {
            this.balance -= amount;
            transactionHistory.add(new Transaction("Withdraw", amount));
            return true;
        }
        return false;
    }

    public boolean transfer(Account recipient, double amount) {
        if (amount <= balance) {
            this.balance -= amount;
            recipient.deposit(amount);
            transactionHistory.add(new Transaction("Transfer", amount));
            return true;
        }
        return false;
    }

    public void printTransactionHistory() {
        for (Transaction transaction : transactionHistory) {
            System.out.println(transaction);
        }
    }
}

class Transaction {
    private String type;
    private double amount;

    public Transaction(String type, double amount) {
        this.type = type;
        this.amount = amount;
    }

    @Override
    public String toString() {
        return "Transaction Type: " + type + ", Amount: " + amount;
    }
}

public class ATM {
    private static Scanner scanner = new Scanner(System.in);
    private static User currentUser;
    private static Account currentAccount;

    public static void main(String[] args) {
        currentUser = new User("user123", "1234"); // Example user ID and PIN
        currentAccount = new Account();

        System.out.println("Welcome to the ATM");
        login();

        int choice;
        do {
            showMenu();
            choice = scanner.nextInt();
            handleMenuChoice(choice);
        } while (choice != 5);
    }

    private static void login() {
        System.out.print("Enter User ID: ");
        String userId = scanner.next();
        System.out.print("Enter PIN: ");
        String pin = scanner.next();

        if (!currentUser.authenticate(userId, pin)) {
            System.out.println("Invalid ID or PIN. Please try again.");
            login();
        } else {
            System.out.println("Login successful!");
        }
    }


    private static void showMenu() {
        System.out.println("\nATM Menu:");
        System.out.println("1. Transaction History");
        System.out.println("2. Withdraw");
        System.out.println("3. Deposit");
        System.out.println("4. Transfer");
        System.out.println("5. Quit");
        System.out.print("Enter your choice: ");
    }

    private static void handleMenuChoice(int choice) {
        switch (choice) {
            case 1:
                currentAccount.printTransactionHistory();
                break;
            case 2:
                System.out.print("Enter amount to withdraw: ");
                double withdrawAmount = scanner.nextDouble();
                if (currentAccount.withdraw(withdrawAmount)) {
                    System.out.println("Withdrawal successful!");
                } else {
                    System.out.println("Insufficient funds!");
                }
                break;
            case 3:
                System.out.print("Enter amount to deposit: ");
                double depositAmount = scanner.nextDouble();
                currentAccount.deposit(depositAmount);
                System.out.println("Deposit successful!");
                break;
            case 4:
                System.out.print("Enter recipient ID: ");
                String recipientId = scanner.next();
                // In a real system, you would need to lookup the recipient’s account
                Account recipient = new Account(); // Placeholder for recipient
                System.out.print("Enter amount to transfer: ");
                double transferAmount = scanner.nextDouble();
                if (currentAccount.transfer(recipient, transferAmount)) {
                    System.out.println("Transfer successful!");
                } else {
                    System.out.println("Insufficient funds!");
                }
                break;
            case 5:
                System.out.println("Exiting ATM. Thank you!");
                break;
            default:
                System.out.println("Invalid choice. Please try again.");
        }
    }
}
