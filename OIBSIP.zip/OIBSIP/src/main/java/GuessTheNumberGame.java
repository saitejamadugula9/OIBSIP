import java.util.Random;
import java.util.Scanner;

public class GuessTheNumberGame {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Welcome to the Guess the Number Game!");

        boolean playAgain = true;
        while (playAgain) {
            // Select difficulty
            System.out.println("Choose difficulty level:");
            System.out.println("1. Easy (1-50, 10 attempts)");
            System.out.println("2. Medium (1-100, 7 attempts)");
            System.out.println("3. Hard (1-200, 5 attempts)");
            int difficulty = scanner.nextInt();

            int maxNumber = switch (difficulty) {
                case 1 -> 50;
                case 2 -> 100;
                case 3 -> 200;
                default -> 100;
            };

            int maxAttempts = switch (difficulty) {
                case 1 -> 10;
                case 2 -> 7;
                case 3 -> 5;
                default -> 7;
            };

            int score = playRound(scanner, maxNumber, maxAttempts);
            System.out.println("Your score for this round: " + score);

            // Ask if they want to play again
            System.out.println("Do you want to play again? (yes/no)");
            playAgain = scanner.next().equalsIgnoreCase("yes");
        }

        System.out.println("Thank you for playing! Goodbye!");
    }

    public static int playRound(Scanner scanner, int maxNumber, int maxAttempts) {
        Random random = new Random();
        int numberToGuess = random.nextInt(maxNumber) + 1;
        int attempts = 0;
        int score = 0;

        System.out.println("Guess the number (between 1 and " + maxNumber + "):");

        while (attempts < maxAttempts) {
            int userGuess = scanner.nextInt();
            attempts++;

            if (userGuess < numberToGuess) {
                System.out.println("Too low!");
            } else if (userGuess > numberToGuess) {
                System.out.println("Too high!");
            } else {
                System.out.println("Congratulations! You guessed the number in " + attempts + " attempts.");
                score = (maxAttempts - attempts + 1) * 10;
                break;
            }

            if (attempts == maxAttempts) {
                System.out.println("Out of attempts! The correct number was " + numberToGuess);
            }
        }

        return score;
    }
}
